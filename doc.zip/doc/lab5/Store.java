import java.util.*;

public class Store {
    private CashRegister cashRegister;
    private LinkedList<Product> products = new LinkedList<Product>();
    
     public static void main(String[] args) {
         new Store().use();
     }
    
    public Store() {
        cashRegister = new CashRegister();
        products.add(new Product("Whiteboard Marker", 85, 1.5));
        products.add(new Product("Whiteboard Eraser", 45, 5.0));
        products.add(new Product("Black Pen", 100, 1.5));
        products.add(new Product("Red Pen", 100, 1.5));
        products.add(new Product("Blue Pen", 100, 1.5));
    }
    
    public void use() {
        char choice;
        while ((choice = readChoice()) != 'x') {
           switch (choice) {
               case 's': sell(); break;
               case 'r': restock(); break;
               case 'v': viewStock(); break;
               case 'c': viewCash(); break;
               case 'p': pruneProducts(); break;
               default: help(); break;
           }
        }
    }
    
    private char readChoice() {
        System.out.print("Choice (s/r/v/c/p/x): ");
        return In.nextChar();
    }

    private void sell() {
        String name = readName();
        Product product = product(name);        
        if (product == null) {      
            System.out.print(printMatches(name));
            return;
        }      
        System.out.println("Selling " + product.getName());
        int n = readNumber();
        if (product.has(n)) {
            cashRegister.add(product.sell(n));
        } else {
            System.out.println("Not enough stock");
        }
    }
    
    private String printMatches(String name) {
        String toPrint = "Multiple products match:\n";
        LinkedList<String> matches = new LinkedList<String>();
        for (Product product : products) {
            if (product.getName().toLowerCase().contains(name.toLowerCase())) {
                 toPrint += product;
                 toPrint += "\n";
                }
            }
        
        if (toPrint == "Multiple products match:\n") return "No such product\n";            
        return toPrint;
    }
    
    private void restock() {
        int n;
        boolean isSim = false;
        String name = readName();
        Product product = product(name);
        if (product == null) {  
            for (Product prod : products) {
                if (prod.getName().toLowerCase().contains(name.toLowerCase())){
                    restocking(prod);
                    isSim = true;
                }
            }
            if (isSim == true) return;
                       
            System.out.println("Adding new product");
            products.add(new Product(name, readNumber(), readPrice()));
            return;
        } 
        restocking(product);
    }
    
    private void restocking(Product product) {
        System.out.println("Restocking " + product.getName());
        int n = readNumber();
        product.restock(n);
    }

    private void viewStock() {
        for (Product product : products){
            System.out.println(product);
        }
    }

    private void viewCash() {
        System.out.println(cashRegister);
    }

    private void pruneProducts() {
        LinkedList<Product> empty = new LinkedList<Product>();
        for (Product product : products) {
            if ((product.isEmpty())) {
               empty.add(product);
            }   
        }
        products.removeAll(empty);
    }

    private String readName() {
        System.out.print("Name: ");
        return In.nextLine();
    }

    private double readPrice() {
        System.out.print("Price: $");
        return In.nextDouble();
    }

    private int readNumber() {
        System.out.print("Number: ");
        return In.nextInt();
    }

    private void help() {
        System.out.println("Menu options");
        System.out.println("s = sell");
        System.out.println("r = restock");
        System.out.println("v = view stock");
        System.out.println("c = view cash");
        System.out.println("p = prune products");
        System.out.println("x = exit");
    }
    
    private Product product(String name) {
        for (Product product : products) {
            if (product.hasName(name)) {
                return product;
            }
        }
        return null;
    }
}
