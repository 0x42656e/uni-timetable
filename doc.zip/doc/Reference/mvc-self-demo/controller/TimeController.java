package controller;

import model.*;
import util.javafx.*;

public class TimeController extends Controller {
    public Time time = new Time();
    
    
    public Time getTime() {
        return time;
    }
}
