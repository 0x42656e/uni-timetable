package model;

public class Sobek {
    public Sobek() {
        System.out.println("Sobek initialised");
    }
}
