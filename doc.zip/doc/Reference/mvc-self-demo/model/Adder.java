package model;

public class Adder {
    public Adder() {
    System.out.println("adder initilaisdssed");
    }
}
