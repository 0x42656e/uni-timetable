Contains the domain model classes
