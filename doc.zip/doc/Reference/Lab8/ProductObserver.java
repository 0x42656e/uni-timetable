public interface ProductObserver {
    void handleSale(double amount);
}