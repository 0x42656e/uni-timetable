import au.edu.uts.ap.javafx.*;
import model.*;

public class ControlsController extends Controller<Customer> {
	public final Customer getCustomer() { return model; }
}
