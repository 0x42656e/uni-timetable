import java.text.*;

/**
 * The cash register stores cash.
 *
 * You can add cash to the cash register.
 */
public class CashRegister {
    private double cash;

    public CashRegister() {
        cash = 0;
    }
    public void addCash(double amount) {
   
        cash += amount;
    }
    // insert 1 method here

    /**
     * Return a string in the form:
     *
     * Cash: $[cash]
     *
     * e.g. "Cash: $29.90"
     */
    @Override
    public String toString() {
        return "Cash: $" + decaa(cash);
    }
    
    private String decaa(double cash) {
        return new DecimalFormat("###,##0.00").format(cash);
    }
}
